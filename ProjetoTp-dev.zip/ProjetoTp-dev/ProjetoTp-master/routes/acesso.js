var express = require('express');
var router = express.Router();

const bcrypt = require('bcrypt');
const saltRounds = 10;


router.post('/login', function (req, res, next) {
    var input = req.body;
    console.log(input);

    req.getConnection(function (err, connection) {
        var query = "SELECT senha FROM Usuarios WHERE usuario = '" + input.login + "'";

        console.log(query);
        connection.query(query, function (err, rows) {

            bcrypt.compare(input.senha, rows[0].senha, function (err, res) {
                console.log(input.senha);
                console.log(rows[0].senha);
                console.log('res object: ' + res);
                if (res) {
                    console.log(rows);
                    if (err)
                        res.json({ status: 'ERRO', data: + err });
                    else {
                        if (rows[0] === undefined)
                            res.json({
                                status: 'ERRO', data: 'Dados de login incorretos!'
                            });
                        else {
                            req.session.logado = true;
                            req.session.login =
                                rows[0].login;
                            res.json({
                                status: 'OK', data:
                                    'Logado com sucesso!'
                            });
                        }
                    }
                }
            });
        });
    });
});

router.post('/logout', function (req, res, next) {
    req.session.destroy(function (err) {
        if (err)
            res.json({ status: 'ERRO', data: + err });
        else
            res.json({ status: 'OK', data: 'Logout com sucesso!' });
    });
});
module.exports = router;